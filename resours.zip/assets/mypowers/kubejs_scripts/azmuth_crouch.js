PalladiumEvents.registerAnimations((event) => {
    event.register('mypowers/azmuthsuit', 15, (builder) => {
        if (abilityUtil.isEnabled(builder.getPlayer(), "mypowers:azmuth", "azmuth_armor")) {
            if (!builder.isFirstPerson()) {
                builder.get('left_arm').rotateX(builder.getModel().leftArm.xRot * -0.4).moveX(4).moveY(8)
                builder.get('right_arm').rotateX(builder.getModel().rightArm.xRot * -0.4).moveX(-4).moveY(8)
                builder.get('right_leg').rotateX(builder.getModel().rightLeg.xRot * -0.4)
                builder.get('left_leg').rotateX(builder.getModel().leftLeg.xRot * -0.4)
            }
            if (builder.isFirstPerson()) {
                builder.get('left_arm').scaleX(0.75).scaleY(0.75).scaleZ(0.75).moveX(4).moveY(5)
                builder.get('right_arm').scaleX(0.75).scaleY(0.75).scaleZ(0.75).moveX(-4).moveY(5)
            }
            if (builder.getPlayer().isCrouching()) {
                builder.get('head').setY(0)
                builder.get('chest').setXRotDegrees(12).setY(0)
                builder.get('left_leg').setY(10)
                builder.get('right_leg').setY(10)
                builder.get('left_arm').setY(2+8).setZ(1.5)
                builder.get('right_arm').setY(2+8).setZ(1.5)
            }
        }
    });
});