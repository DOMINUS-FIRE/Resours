PalladiumEvents.registerAnimations((event) => {
    event.register('arm_fix', 200, (builder) => {
      let stance = animationUtil.getAnimationTimerAbilityValue(builder.getPlayer(), 'gax_classic:aliens/alien_170/enhanced_chimera_sui_generis','arm_fix',builder.getPartialTicks());
        if (stance > 0) {
          if (builder.isFirstPerson()) {
            builder.get('right_arm')
              .setZ(3)
              .setY(3)
              .setYRot(175)
              .scaleX(5)
              .scaleY(5)
              .scaleZ(5)
            builder.get('left_arm')
              .setZ(3)
              .setY(-3)
              .setYRot(-175)
              .scaleX(5)
              .scaleY(5)
              .scaleZ(5)
            }
        }
    });
})